# Multi Step Form With Reactjs, Tailwindcss, Vitejs and Typescript 

Add a multi-step form to get user information or anything else you want.

## Demo


## Installation 

Install all dependencies

```
npm install
```

Run app

```
npm run dev
```
